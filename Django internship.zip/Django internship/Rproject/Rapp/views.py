from django.shortcuts import render,redirect
from .models import User,Slot,Menu,Upload
from .forms import UsrForm,SlotForm,MenuForm,UploadForm
from django.core.mail import send_mail
from Rproject import settings
from django.contrib import messages
# Create your views here.

def home(request):
	return render(request,'html/home.html')

def video(request):
	g = Upload.objects.all()
	return render(request,'html/video.html',{'h':g})
	
def about(request):
	return render(request,'html/about.html')

def menu(request):
	s = Menu.objects.all()
	return render(request,'html/menu.html',{'p':s})

def dish(request):
	j = Menu.objects.all()
	if request.method == "POST":
		a = MenuForm(request.POST)
		if a.is_valid():
			a.save()
			return redirect('/dish')
	a = MenuForm()
	return render(request,'html/dishes.html',{'b':a,'k':j})

def registration(request):
	if request.method == "POST":
		g = UsrForm(request.POST)
		if g.is_valid():
			g.save()
			return redirect('/login')
	g = UsrForm()
	return render(request,'html/registration.html',{'t':g})

def upload(request):
	e = Upload.objects.all()
	if request.method == "POST":
		c = UploadForm(request.POST,request.FILES)
		if c.is_valid():
			c.save()
			return redirect('/upload')
	else:
		c = UploadForm()
	return render(request,'html/upload.html',{'d':c,'f':e})

def contact(request):
	if request.method == "POST":
		e = request.POST['em'].split(',')
		s = request.POST['sb']
		d = request.POST['des']
		y = settings.EMAIL_HOST_USER
		z = send_mail(s,d,y,e)
		if z==1:
			messages.success(request,"Mail Sent Successfully")
			return redirect('/cnt')
		else:
			return HttpResponse("Not Sent")
	return render(request,'html/contact.html')

def booking(request):
	l = Slot.objects.all()
	if request.method == "POST":
		t = SlotForm(request.POST)
		if t.is_valid():
			t.save()
			return redirect('/slot')
	t = SlotForm()
	return render(request,'html/slotbooking.html',{'r':t,'m':l})	

def page(request):
	return render(request,'html/slotpage.html')


