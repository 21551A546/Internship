from django.core.exceptions import validationError

def file_size(value):
	filesize=value.file_size
	if filesize>10000000:
		raise validationError("maximum size is 10 MB")