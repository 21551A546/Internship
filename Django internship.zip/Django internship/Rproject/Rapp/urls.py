from django.urls import path
from . import views
from django.contrib.auth import views as ad
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.home,name="hm"),
    path('abt/',views.about,name="ab"),
    path('dish/',views.dish,name="di"),
    path('reg/',views.registration,name="rg"),
    path('login/',ad.LoginView.as_view(template_name="html/login.html"),name="ln"),
    path('logout/',ad.LogoutView.as_view(template_name="html/logout.html"),name="lt"),
    path('upload/',views.upload,name="up"),
    path('cnt/',views.contact,name="ct"),
    path('slot/',views.booking,name="sb"),
    path('page/',views.page,name="pa"),
    path('details/',views.video,name="de"),
    path('menu/',views.menu,name="mn"),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

 
