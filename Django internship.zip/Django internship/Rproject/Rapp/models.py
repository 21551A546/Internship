from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.
class User(AbstractUser):
	c = [
		('0','Guest'),
		('1','Admin'),
	]
	role_type = models.CharField(max_length=5,choices=c,default='0')
	
class Slot(models.Model):
	name = models.CharField(max_length=100,null=True,blank=True)
	mail =  models.CharField(max_length=100,null=True,blank=True)

class Menu(models.Model):
	name = models.CharField(max_length=100,null=True,blank=True)
	image = models.ImageField(upload_to="images/",default='null')
	value =  models.CharField(max_length=100,null=True,blank=True)

class Upload(models.Model):
	name = models.CharField(max_length=100,null=True,blank=True)
	date =  models.DateField(max_length=100,null=True,blank=True)
	time =  models.TimeField(max_length=100,null=True,blank=True)
	video = models.FileField(upload_to="videos/")

	



	



